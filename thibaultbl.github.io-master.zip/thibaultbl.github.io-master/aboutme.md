---
layout: page
title: About me
subtitle: Why you'd want to go on a date with me
---

My name is Thibault Blanc. I currently work as a data scientist @Orange, leading telecom company in France.

I come from a heavy statistic & machine learning background with a strong coding specialization.

I initialy started this blog to have a way to put my D3.js attempts online, but you will probably find everything related to datascience, software engineering, and data-related fields.

