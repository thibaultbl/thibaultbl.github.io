#My blog

Insipred by theme "Beautiful Jekyll" by Dean Attali: 

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.me/daattali/20)
[![Gem Version](https://badge.fury.io/rb/beautiful-jekyll-theme.svg)](https://badge.fury.io/rb/beautiful-jekyll-theme)

> *Copyright 2016 [Dean Attali](http://deanattali.com)*
